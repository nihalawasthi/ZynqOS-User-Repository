/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const calculate: (a: number, b: number) => number;
export const concat_operands: (a: number, b: number) => [number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
